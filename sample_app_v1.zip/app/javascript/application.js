// app/javascript/application.js

import "@hotwired/turbo-rails"
import Rails from "@rails/ujs"

Rails.start()