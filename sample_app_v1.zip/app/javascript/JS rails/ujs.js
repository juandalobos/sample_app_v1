import "@hotwired/turbo-rails"
import "./rails/ujs"