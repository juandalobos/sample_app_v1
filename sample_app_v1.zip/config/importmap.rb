pin "@hotwired/turbo-rails", to: "turbo.min.js", preload: true
pin "@rails/ujs", to: "rails/ujs.js"
pin "application", to: "application.js"